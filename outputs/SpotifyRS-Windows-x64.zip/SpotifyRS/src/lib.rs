pub mod api;
pub mod auth;
mod credentials;
pub mod library;
pub mod model;
pub mod settings;
pub mod soloist;
pub mod soloist_launcher;
pub mod worker;
